﻿using Heroes.Model;

namespace Heroes.DAO
{
    public class SQLiteDAO : IHeroesDao
    {
        public bool AddHero(Hero hero)
        {
            throw new NotImplementedException();
        }

        public Hero GetHero(int heroId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Hero> GetHeroes()
        {
            throw new NotImplementedException();
        }

        public bool ModifyHero(Hero hero)
        {
            throw new NotImplementedException();
        }
    }
}
